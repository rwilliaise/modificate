
print("Hello, world!")
